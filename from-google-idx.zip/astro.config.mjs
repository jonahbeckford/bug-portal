// @ts-check
import { defineConfig } from 'astro/config';
import remarkToc from 'remark-toc';

// https://astro.build/config
export default defineConfig({
	site: 'https://example.com',
	markdown: {
		// This is from https://docs.astro.build/en/guides/markdown-content/#customizing-a-plugin
		remarkPlugins: [ [remarkToc, { heading: 'Contents', maxDepth: 3 } ] ],
	}
});
